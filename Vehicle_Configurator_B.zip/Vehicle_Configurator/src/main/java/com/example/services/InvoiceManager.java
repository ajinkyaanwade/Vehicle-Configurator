package com.example.services;
import com.example.entities.Invoice;

public interface InvoiceManager {

	public void createInvoice(Invoice invoice);
}

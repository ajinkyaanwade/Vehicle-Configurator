package com.example.services;

public interface ComponentManager {

}

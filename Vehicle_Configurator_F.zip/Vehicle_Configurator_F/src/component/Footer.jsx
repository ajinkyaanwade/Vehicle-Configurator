import React from 'react';
import './Footer.css'; // Import the CSS file for styling

function Footer() {
  return (
    <footer>

    <p>&copy; 2024.nexcar. All rights reserved.</p>
  </footer>
  );
}

export default Footer;

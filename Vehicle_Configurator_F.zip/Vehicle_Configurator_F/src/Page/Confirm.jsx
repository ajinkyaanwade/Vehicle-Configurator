function Confirm() {
    const Model_id = sessionStorage.getItem("Model_id");
    const quantity = sessionStorage.getItem("quantity");
    const totalprice= sessionStorage.getItem("totalprice");

   

    return (
        <div>
            
        </div>
    )
}

export default Confirm
